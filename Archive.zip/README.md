Public email
1.
2.

Back-end:

PHP Laravel/Valet


Version:

PHP 7.1.16

Laravel 5.6
https://laravel.com/docs/5.6

Installation:

Using homebrew install PHP 7.1

install valet using `composer global require laravel/valet` and add `~/.composer/vendor/bin` to your `$PATH` if you need (google it)

`valet link` in the directory you cloned `xDog` to then `valet secure` and go to `https://{directory_name}.test` in a browser
so if it's called xDog, go to `https://xDog.dev`

//(not now)set up the database using `php artisan migrate`



Front end

Angular JS for now, TBD
